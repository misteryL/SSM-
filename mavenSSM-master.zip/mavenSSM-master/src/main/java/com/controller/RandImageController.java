package com.controller;

import com.service.RandImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author: 刘帅彪
 * @createDate: 2021/9/12
 */
@Controller
@RequestMapping("/land")
public class RandImageController {
    @Autowired
    private RandImageService randImageService;
    @RequestMapping("/find")
    public String findRandImage(Model model) {
        System.out.println("Controller层：findRandImage方法执行……");
        //调用service层的方法
        String imageAdress = randImageService.find();
        model.addAttribute("imageAdress",imageAdress);
        return "randomtest";
    }
}