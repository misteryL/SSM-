package com.service;

import org.springframework.stereotype.Service;

/**
 * @author: 刘帅彪
 * @createDate: 2021/9/12
 */
@Service
public interface RandImageService {
    public String find();
}
