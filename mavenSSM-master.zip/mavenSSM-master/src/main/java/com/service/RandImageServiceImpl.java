package com.service;

import com.dao.RandImageMapper;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author: 刘帅彪
 * @createDate: 2021/9/12
 */
public class RandImageServiceImpl implements RandImageService{
    @Autowired
    private RandImageMapper randImageMapper;

    public void setRandImageMapper(RandImageMapper randImageMapper) {
        this.randImageMapper = randImageMapper;
    }

    @Override
    public String find() {
        String result=randImageMapper.find();
        return result;
    }
}
