package com.dao;

import org.springframework.stereotype.Repository;

/**
 * @author: 刘帅彪
 * @createDate: 2021/9/12
 */
public interface RandImageMapper {
    public String find();
}
